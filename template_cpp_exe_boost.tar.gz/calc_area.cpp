#include <boost/geometry.hpp>
#include <boost/geometry/geometries/geometries.hpp>

#include "calc_area.hpp"

namespace bg = boost::geometry;

double calc_area() {
    using point_t = bg::model::point<double, 2, bg::cs::cartesian>;
    using polygon_t = bg::model::polygon<point_t>;

    polygon_t poly1;

    polygon_t polygon2{{{0.0, 0.0}, {0.0, 5.0}, {5.0, 5.0}, {5.0, 0.0}, {0.0, 0.0}},
                       {{1.0, 1.0}, {4.0, 1.0}, {4.0, 4.0}, {1.0, 4.0}, {1.0, 1.0}}};

    bg::append(poly1.outer(), point_t(0.0, 0.0));
    bg::append(poly1.outer(), point_t(0.0, 5.0));
    bg::append(poly1.outer(), point_t(5.0, 5.0));
    bg::append(poly1.outer(), point_t(5.0, 0.0));
    bg::append(poly1.outer(), point_t(0.0, 0.0));

    poly1.inners().resize(1);
    bg::append(poly1.inners()[0], point_t(1.0, 1.0));
    bg::append(poly1.inners()[0], point_t(4.0, 1.0));
    bg::append(poly1.inners()[0], point_t(4.0, 4.0));
    bg::append(poly1.inners()[0], point_t(1.0, 4.0));
    bg::append(poly1.inners()[0], point_t(1.0, 1.0));

    return bg::area(poly1);
}
