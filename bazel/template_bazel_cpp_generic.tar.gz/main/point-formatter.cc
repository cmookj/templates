#include "main/point-formatter.h"

std::string
to_string (const Point& pt) {
    return std::format ("({}, {})", pt.x, pt.y);
}
