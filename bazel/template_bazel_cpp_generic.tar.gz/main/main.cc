#include "lib/point.h"
#include "main/point-formatter.h"

#include <print>

int
main (int argc, char* argv[]) {
    Point point{2, 8};

    std::println ("Hello, World!");
    std::println ("The speed is {}, mass is {}, name is {}, point is {}", 5.5f, 40, "John", point);

    Point a{1, 3};
    Point b{2, 4};
    std::println ("The sum of points is {}", a + b);

    return 0;
}
