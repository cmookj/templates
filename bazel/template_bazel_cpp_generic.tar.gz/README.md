# Basic C++23 Template for C++ Projects

This `BUILD` file indicates to build a C++ library and binary using the `cc_library` and `cc_binary` rule,
respectively, provided by Bazel.

In the `cc_library` rule
* `name` attribute: the name of the library
* `srcs` attribute: source files
* `hdrs` attribute: header files
* `visibility` attribute: makes `point` library visible to `main` package
* `deps` attribute: dependencies

In the `cc_binary` rule
* `name` attribute: the name of the binary
* `srcs` attribute: source files
* `deps` attribute: dependencies

In `lib/BUILD`:
```
cc_library(
    name = "point",
    srcs = ["point.cc"],
    hdrs = ["point.h"],
    visibility = ["//main:__pkg__"],
)
```

In `main/BUILD`:
```
cc_library(
    name = "point-formatter",
    srcs = ["point-formatter.cc"],
    hdrs = ["point-formatter.h"],
    deps = [
        "//lib:point",
    ],
)

cc_binary(
    name = "hello",
    srcs = ["main.cc"],
    deps = [
        ":point-formatter",
        "//lib:point",
    ],
)
```

To build:
```
bazel build --cxxopt=-std=c++23 //main:hello
```

To print output file path:
```
bazel cquery --output=files //main:hello
```
