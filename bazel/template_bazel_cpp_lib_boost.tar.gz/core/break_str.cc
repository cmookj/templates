#include <boost/algorithm/string.hpp>
#include <iostream>
#include <string>
#include <vector>

std::vector<std::string>
break_str () {
    std::string              text = "Boost makes C++ modular!";
    std::vector<std::string> words;
    boost::split (words, text, boost::is_any_of (" "));
    return words;
    // for (auto& w : words)
    // std::cout << w << std::endl;
}
