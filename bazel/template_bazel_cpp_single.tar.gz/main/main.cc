#include <format>
#include <print>

struct Point {
    int x, y;
};

template <> struct std::formatter<Point> : std::formatter<std::string> {
    auto
    format (const Point& p, format_context& ctx) const {
        return std::formatter<std::string>::format (std::format ("({}, {})", p.x, p.y), ctx);
    }
};

int
main (int argc, char* argv[]) {
    Point point{2, 8};

    std::println ("Hello, World!");
    std::println ("The speed is {}, mass is {}, name is {}, point is {}", 5.5f, 40, "John", point);

    return 0;
}
