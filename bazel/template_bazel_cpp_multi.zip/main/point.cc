#include "point.h"

Point&
Point::operator+= (const Point& pt) {
    this->x += pt.x;
    this->y += pt.y;

    return *this;
}

Point&
Point::operator-= (const Point& pt) {
    this->x -= pt.x;
    this->y -= pt.y;

    return *this;
}

Point
operator+ (const Point& a, const Point& b) {
    return Point{a.x + b.x, a.y + b.y};
}

Point
operator- (const Point& a, const Point& b) {
    return Point{a.x - b.x, a.y - b.y};
}
