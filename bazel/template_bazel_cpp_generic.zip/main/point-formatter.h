#ifndef __POINT_FORMATTER_H__
#define __POINT_FORMATTER_H__

#include "lib/point.h"

#include <format>
#include <string>

template <> struct std::formatter<Point> : std::formatter<std::string> {
    auto
    format (const Point& p, format_context& ctx) const {
        return std::formatter<std::string>::format (std::format ("({}, {})", p.x, p.y), ctx);
    }
};

std::string
to_string (const Point&);

#endif
