#ifndef __POINT_H__
#define __POINT_H__

#include <format>

struct Point {
    int x, y;

    Point&
    operator+= (const Point&);

    Point&
    operator-= (const Point&);
};

Point
operator+ (const Point&, const Point&);

Point
operator- (const Point&, const Point&);

#endif
