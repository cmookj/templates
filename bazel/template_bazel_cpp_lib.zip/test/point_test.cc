#include <gtest/gtest.h>

#include "core/point.h"

// Demonstrate some basic assertions.
TEST (PointTest, BasicAssertions) {
    // Expect two strings not to be equal.
    EXPECT_STRNE ("hello", "world");

    // Expect equality.
    EXPECT_EQ (7 * 6, 42);
}

// Point Algebra
TEST (PointTest, Algebra) {
    Point a{1, 2};
    Point b{3, 4};

    Point sum  = a + b;
    Point diff = a - b;

    EXPECT_EQ (sum.x, 4);
    EXPECT_EQ (sum.y, 6);

    EXPECT_EQ (diff.x, -2);
    EXPECT_EQ (diff.y, -2);
}

// Point Output
TEST (PointTest, Conversion) {
    Point a{1, 3};

    ASSERT_TRUE (to_string (a) == std::string{"(1, 3)"});
}
