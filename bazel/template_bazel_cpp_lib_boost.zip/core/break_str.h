#include <string>
#include <vector>

std::vector<std::string>
break_str ();
