#include <gtest/gtest.h>

#include "core/break_str.h"
#include "core/calc_area.h"

// String Break
TEST (StringBreakTest, BasicAssertions) {
    auto words = break_str();
    EXPECT_TRUE (words[0] == "Boost");
}

// Calculate area
TEST (GeometryTest, Algebra) { EXPECT_NEAR (calc_area(), 16.0, 1e-6); }
