#ifndef __POINT_H__
#define __POINT_H__

#include <format>
#include <string>

struct Point {
    int x, y;

    Point&
    operator+= (const Point&);

    Point&
    operator-= (const Point&);
};

Point
operator+ (const Point&, const Point&);

Point
operator- (const Point&, const Point&);

template <> struct std::formatter<Point> : std::formatter<std::string> {
    auto
    format (const Point& p, format_context& ctx) const {
        return std::formatter<std::string>::format (std::format ("({}, {})", p.x, p.y), ctx);
    }
};

std::string
to_string (const Point&);

#endif
