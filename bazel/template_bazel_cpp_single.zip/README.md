# Basic C++23 Template for C++ Projects

This `BUILD` file indicates to build a C++ binary using the `cc_binary` rule provided by Bazel.
In the `cc_binary` rule
* `name` attribute: the name of the binary
* `srcs` attribute: source files

```
cc_binary(
    name = "hello",
    srcs = ["main.cc"],
)
```

To build:
```
bazel build --cxxopt=-std=c++23 //main:hello
```

To print output file path:
```
bazel cquery --output=files //main:hello
```
