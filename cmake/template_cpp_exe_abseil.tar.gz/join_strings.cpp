#include "absl/strings/str_join.h"
#include "join_strings.hpp"

#include <sstream>
#include <string>
#include <vector>

std::string join_strings() {
    std::vector<std::string> v = { "foo", "bar", "baz" };
    std::string s = absl::StrJoin(v, "-");

    std::stringstream strm;
    strm << "Joined string: " << s << "\n";

    return strm.str();
}
