include(FetchContent)
FetchContent_Declare(
  absl
  URL https://github.com/abseil/abseil-cpp/archive/refs/tags/20260107.1.zip
  DOWNLOAD_EXTRACT_TIMESTAMP TRUE
)
FetchContent_MakeAvailable(absl)

find_package(Boost CONFIG)
list(APPEND LIBRARY_FILES ${Boost_LIBRARIES})
include_directories(${Boost_INCLUDE_DIRS})
