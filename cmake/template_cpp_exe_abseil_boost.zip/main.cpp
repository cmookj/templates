#include "join_strings.hpp"
#include "calc_area.hpp"

#include <iostream>

int main(int argc, char* argv[]) {
    std::cout << "Hello, World!\n";
    std::cout << join_strings();
    std::cout << "Area of a polygon: " << calc_area() << "\n";

    return 0;
}
