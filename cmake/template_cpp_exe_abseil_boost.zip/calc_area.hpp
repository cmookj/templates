double calc_area();
