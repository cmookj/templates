#include <string>

std::string join_strings();
