#include <stdio.h>
#include <string.h>

#define MAXLINE 1000

int get_line (char*, int);

/* find:  print lines that match pattern from 1st arg */
int main (int argc, char* argv[]) {
  char line[MAXLINE];
  long lineno = 0;
  int  c, except = 0, number = 0, found = 0;

  while (--argc > 0 && (*++argv)[0] == '-')
    while ((c = *++argv[0]))
      switch (c) {
      case 'x': except = 1; break;
      case 'n': number = 1; break;
      default:
        printf ("find: illegal option %c\n", c);
        argc  = 0;
        found = -1;
        break;
      }
  if (argc != 1) printf ("Usage: find -x -n pattern\n");
  else
    while (get_line (line, MAXLINE) > 0) {
      lineno++;
      if ((strstr (line, *argv) != NULL) != except) {
        if (number) printf ("%ld:", lineno);
        printf ("%s", line);
      }
    }
  return found;
}

/* get_line:  read a line of string upto the `lim` characters */
int get_line (char* buf, int lim) {
  int c, nchar = 0;
  while (--lim > 0 && (c = getchar()) != EOF && c != '\n') {
    *buf++ = c;
    nchar++;
  }
  if (c == '\n') {
    *buf++ = c;
    nchar++;
  }
  *buf = '\0';
  return nchar;
}
