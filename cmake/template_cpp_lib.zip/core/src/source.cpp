#include "header.hpp"

int
get_integer () {
    return 42;
}
