int get_integer();
