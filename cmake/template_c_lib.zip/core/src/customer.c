#include "customer.h"

int
customer_check (int a) {
    return a == 5;
}
