#ifndef _CUSTOMER_H_
#define _CUSTOMER_H_

int customer_check(int);

#endif
