#include "join_strings.hpp"

#include <iostream>

int main(int argc, char* argv[]) {
    std::cout << "Hello, World!\n";
    std::cout << join_strings();

    return 0;
}
