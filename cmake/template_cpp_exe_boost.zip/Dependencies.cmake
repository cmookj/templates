find_package(Boost CONFIG)
list(APPEND LIBRARY_FILES ${Boost_LIBRARIES})
include_directories(${Boost_INCLUDE_DIRS})
