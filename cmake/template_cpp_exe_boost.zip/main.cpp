#include "calc_area.hpp"

#include <iostream>

int main(int argc, char* argv[]) {
    std::cout << "Hello, World!\n";
    std::cout << "Area of a polygon: " << calc_area() << "\n";

    return 0;
}
