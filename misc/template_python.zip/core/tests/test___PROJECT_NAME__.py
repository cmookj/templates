# This is the test module containing unit tests for the calculator functions.

import unittest
import __PROJECT_NAME__

class TestCalculator(unittest.TestCase):
    def test_add(self):
        self.assertEqual(__PROJECT_NAME__.add(2, 3), 5)
        self.assertEqual(__PROJECT_NAME__.add(-1, 1), 0)
        self.assertEqual(__PROJECT_NAME__.add(0, 0), 0)

    def test_subtract(self):
        self.assertEqual(__PROJECT_NAME__.subtract(10, 5), 5)
        self.assertEqual(__PROJECT_NAME__.subtract(0, 0), 0)
        self.assertEqual(__PROJECT_NAME__.subtract(5, 10), -5)

    def test_multiply(self):
        self.assertEqual(__PROJECT_NAME__.multiply(3, 4), 12)
        self.assertEqual(__PROJECT_NAME__.multiply(-2, 3), -6)
        self.assertEqual(__PROJECT_NAME__.multiply(0, 10), 0)

    def test_divide(self):
        self.assertEqual(__PROJECT_NAME__.divide(10, 2), 5)
        self.assertEqual(__PROJECT_NAME__.divide(9, 3), 3)
        with self.assertRaises(ZeroDivisionError):
            __PROJECT_NAME__.divide(10, 0)

# Entry point for running tests
if __name__ == '__main__':
    unittest.main()
