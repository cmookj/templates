#ifndef _WIDGET_H_
#define _WIDGET_H_

int widget_ok(int, int);

#endif
